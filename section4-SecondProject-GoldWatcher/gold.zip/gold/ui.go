package main

func (app *Config) makeUI() {
	// get the current price of gold

	// put price information into a container

	// add container to window
	
}